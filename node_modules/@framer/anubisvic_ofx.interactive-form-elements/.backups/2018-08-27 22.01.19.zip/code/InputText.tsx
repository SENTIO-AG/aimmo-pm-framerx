import * as React from "react"
import { PropertyControls, ControlType } from "framer"

interface Props {
    value: string
    onValueChange: (value: string) => void
    placeholder: string
    backgroundColor: string
    textColor: string
    fontSize: number
    width: number
    height: number
    borderRadius: number
    padding: number
}

interface State {
    value: string
}

export class InputText extends React.Component<Partial<Props>, State> {
    static defaultProps = {
        value: "",
        placeholder: "Placeholder",
        width: 200,
        height: 40,
        backgroundColor: "rgba(255,255,255,0)",
        textColor: "black",
        fontSize: 20
        borderRadius: 0,
        padding: 8,
    }

    static propertyControls: PropertyControls<Props> = {
        value: { type: ControlType.String, title: "Value" },
        placeholder: { type: ControlType.String, title: "Placeholder" },
        backgroundColor: { type: ControlType.Color, title: "Background" },
        textColor: { type: ControlType.Color, title: "Text" },
        fontSize: { type: ControlType.Number, title: "Text Size" },
        borderRadius: { type: ControlType.Number, title: "Radius" },
        padding: { type: ControlType.Number, title: "Padding" },
    }

    state = {
        value: InputText.defaultProps.value,
    }

    componentDidMount() {
        const { value } = this.props
        this.setState({ value })
    }

    componentWillReceiveProps(props: Props) {
        if (props.value !== this.props.value) {
            this.setState({ value: props.value })
        }
    }

    onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const element = event.nativeEvent.target as HTMLInputElement
        const value = element.value
        this.setState({ value })
        if (this.props.onValueChange) this.props.onValueChange(value)
    }

    render() {
        const { placeholder, backgroundColor, textColor, borderRadius, padding, fontSize } = this.props
        const { value } = this.state
        return (
            <input
                onChange={this.onChange}
                value={value}
                placeholder={placeholder}
                style={{ ...style, backgroundColor, color: textColor, borderRadius: borderRadius, padding: padding, fontSize: fontSize }}
            />
        )
    }
}

const style: React.CSSProperties = {
    border: "none",
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    outline: "none",
    boxSizing: "border-box",
}
