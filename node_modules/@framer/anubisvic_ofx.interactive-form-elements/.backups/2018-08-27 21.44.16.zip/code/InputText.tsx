import * as React from "react"
import { PropertyControls, ControlType } from "framer"

interface Props {
    value: string
    onValueChange: (value: string) => void
    placeholder: string
    backgroundColor: string
    textColor: string
    width: number
    height: number
}

interface State {
    value: string
}

export class InputText extends React.Component<Partial<Props>, State> {
    static defaultProps = {
        value: "",
        placeholder: "Placeholder",
        width: 200,
        height: 36,
        backgroundColor: "rgba(255,255,255,0)",
        textColor: "black",
        borderRadius: 0,
    }

    static propertyControls: PropertyControls<Props> = {
        value: { type: ControlType.String, title: "Value" },
        placeholder: { type: ControlType.String, title: "Placeholder" },
        backgroundColor: { type: ControlType.Color, title: "Background" },
        textColor: { type: ControlType.Color, title: "Text" },
        borderRadius: { type: ControlType.Number, title: "Radius" },
    }

    state = {
        value: InputText.defaultProps.value,
    }

    componentDidMount() {
        const { value } = this.props
        this.setState({ value })
    }

    componentWillReceiveProps(props: Props) {
        if (props.value !== this.props.value) {
            this.setState({ value: props.value })
        }
    }

    onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const element = event.nativeEvent.target as HTMLInputElement
        const value = element.value
        this.setState({ value })
        if (this.props.onValueChange) this.props.onValueChange(value)
    }

    render() {
        const { placeholder, backgroundColor, textColor, borderRadius } = this.props
        const { value } = this.state
        return (
            <input
                onChange={this.onChange}
                value={value}
                placeholder={placeholder}
                style={{ ...style, backgroundColor, color: textColor, borderRadius: borderRadius }}
            />
        )
    }
}

const style: React.CSSProperties = {
    border: "none",
    paddingLeft: 8,
    paddingRight: 8,
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
}
